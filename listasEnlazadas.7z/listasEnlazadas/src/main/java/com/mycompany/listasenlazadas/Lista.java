package com.mycompany.listasenlazadas;

public class Lista {
    private Nodo inicio;
    private int tamanio;

    public Lista() {
        this.inicio = null;
        this.tamanio = 0;  
    }
    public boolean esVacia(){
        return inicio == null;
    }
    public void agregarAlInicio(int valor){
       
        Nodo nuevo = new Nodo();
        nuevo.setValor(valor);
        if (esVacia()) {
            inicio = nuevo;
        } else{
            nuevo.setSiguiente(inicio);
           inicio = nuevo;
        }
        tamanio++;
    }
    public void borrar (int elem){
        if (inicio == null)
            System.out.println("Lista Vacia");
        else 
            if(inicio.getValor() == elem){
                inicio = inicio.getSiguiente();
                tamanio--;
            }
            else{
                Nodo actual = inicio;
                while (actual.getSiguiente()!=null && actual.getSiguiente().getValor() != elem) 
                 actual = actual.getSiguiente();
                if(actual.getSiguiente()==null)
                    System.out.println("elemento " + elem + " no esta en la lista");
                else{
                    actual.setSiguiente(actual.getSiguiente().getSiguiente());
                    tamanio--;
                }
                
            }
        
    }
    public void listar(){
    
    Nodo actual = inicio;
    while (actual.getSiguiente()!= null){
        System.out.println(actual.getValor());
        actual = actual.getSiguiente();
    
    }
    System.out.println(actual.getValor());
}
}
