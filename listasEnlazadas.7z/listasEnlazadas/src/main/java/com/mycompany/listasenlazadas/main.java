package com.mycompany.listasenlazadas;

public class main {
    public static void main(String[] args) {
        System.out.println("Empecemos :D");
        Lista lista= new Lista();
        lista.agregarAlInicio(4);
        lista.agregarAlInicio(3);
        lista.agregarAlInicio(5);
        System.out.println("Listamos desde main ");
      lista.listar();
      System.out.println("Borramos un Elemento ");
      lista.borrar(2);
      lista.borrar(5);
      System.out.println("volvemos a listar ");
      lista.listar();
        
    }
    
}
